<?php
class DocumentFilter 
{
public $id;
public $numero;
public $date;
public $raisonSociale;
public $matriculeFiscal;
public $nomLng1;
public $prenomLng1;
public $adresseLng1;
public $villeLng1;
public $referenceLivreur;
public $urlLivreur;
public $regionLng1;
public $pays;
public $telephone;
public $faxe;
public $mobile1;
public $mobile2;
public $email;
public $typeDocument;
public $isDeleted;
public $etat;
public $totalHt;
public $totalTva;
public $totalTtc;
public $idCollaborateur;
public $idUser;
public $idUserCommerciale;
}
