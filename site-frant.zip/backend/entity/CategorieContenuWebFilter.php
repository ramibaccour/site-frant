<?php
class CategorieContenuWebFilter
{
public $id;
public $idCategorie;
public $idContenuWeb;
}
