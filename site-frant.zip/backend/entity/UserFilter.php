<?php
class UserFilter
{
public $id;
public $username;
public $password;
public $pourcentCommission;
public $isDeleted;
public $idGroupeModule;
public $idLng;
public $idPersonne;
public $idDefaultMenu;
public $idUser;
public $idTypeUser;
}
