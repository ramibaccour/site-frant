<?php
class ParametreFilter
{
public $id;
public $name;
public $value;
public $type;
public $subType;
public $typeContent;
public $ordre;
public $visible;
public $idResolution;
}
