<?php
class TypeUserFilter
{
public $id;
public $nomLng1;
public $nomLng2;
public $nomLng3;
}
