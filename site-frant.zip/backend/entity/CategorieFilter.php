<?php
class CategorieFilter
{
public $id;
public $nomLng1;
public $nomLng2;
public $nomLng3;
public $descriptionLng1;
public $isDeleted;
public $ordre;
public $idParent;
public $idUser;
public $titleSeo;
public $descriptionSeo;
public $listId;
public $type;
}
