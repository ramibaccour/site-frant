<?php
class ImageFilter
{
public $id; // number
public $nom; // string
public $ordre; // number
public $isDeleted; // number
public $idResolution; // number
public $idCouleur; // number
public $idCategorie; // number
public $idParametre; // number
public $idUser; // number
public $idArticle; // number
}
