<?php
class EtatDocumentFilter
{
    public $id;
    public $nomLng1;
    public $ordre;
    public $visible;
}
