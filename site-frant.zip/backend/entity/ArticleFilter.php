<?php
class ArticleFilter
{
public $id;
public $nomLng1;
public $nomLng2;
public $nomLng3;
public $nom2Lng1;
public $descriptionLng1;
public $fullDescriptionLng1;
public $codeBarre;
public $referenceInterne;
public $referenceFournisseur;
public $typeArticle;
public $remiseMax;
public $isDeleted;
public $typeContent;
public $price;
public $newPrice;
public $debutPromo;
public $finPromo;
public $badge;
public $disponible;
public $quantite;
public $valider;
public $titleSeo;
public $descriptionSeo;
public $date1;
public $idModelAffichage;
public $idUnite;
public $idCollaborateur;
public $idTva;
public $idMarque;
public $idUser;
}
