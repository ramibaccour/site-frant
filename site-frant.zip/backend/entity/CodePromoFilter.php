<?php
class CodePromoFilter
{
    public $id;
    public $code;
    public $reductionValue;
    public $reductionPercent;
    public $etat;
    public $debutPromo;
    public $finPromo;
    public $utilisationUnique;
    public $isDeleted;
}