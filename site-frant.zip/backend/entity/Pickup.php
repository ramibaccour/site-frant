<?php
class Pickup
{
public $code_barre;
public $tracking_number;
public $frs;
public $id_frs;
public $agence;
public $date_add;
public $date_pick;
public $prix;
public $nom;
public $gouvernerat;
public $ville;
public $adresse;
public $tel;
public $tel2;
public $designation;
public $nb_article;
public $msg;
public $etat;
public $paye;
public $date_stat;
public $agence_dest;
public $transmit;
public $recu;
public $id_recette;
public $unlink;
public $modif;
public $id_runsheet;
public $login;
public $pwd;
public $echange;
}
