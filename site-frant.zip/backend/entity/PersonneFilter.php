<?php
    class PersonneFilter
    {
        public $id;
        public $nomLng1;
        public $nomLng2;
        public $nomLng3;
        public $prenomLng1;
        public $prenomLng2;
        public $prenomLng3;
        public $civilite;
        public $isDeleted;
        public $idUser;
        public $idImage;
    }
