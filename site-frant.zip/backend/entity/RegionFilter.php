<?php
class RegionFilter
{
public $id;
public $regionLng1;
public $regionLng2;
public $regionLng3;
}
