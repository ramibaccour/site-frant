<?php
class ArticleCategorieFilter
{
public $id;
public $idArticle ;
public $idCategorie;
}
