<?php
class DetailDocumentFilter
{
public $id;
public $nomArticle;
public $referenceInterne;
public $nomUnite;
public $quantiteArticle;
public $articlePrix;
public $remise;
public $tauxTva;
public $idArticle;
public $idDocument;
public $totalHt;
}
