
<?php
    class ArticleRelationFilter
    {
        public $id;
        public $nomLng1;
        public $textLng1;
        public $idArticle;
        public $idArticleRelation;
        public $ordre;
        public $idParent;
    }

