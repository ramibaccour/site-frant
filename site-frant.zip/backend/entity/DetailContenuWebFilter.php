<?php
class DetailContenuWebFilter
{
public $id;
public $nomLng1;
public $nom2Lng1;
public $textLng1;
public $tex2Lng1;
public $image;
public $number1;
public $ordre;
public $isDeleted;
public $facebook;
public $linkedin;
public $idParent;
public $idContenuWeb;
public $idArticle;
public $idCategorie;
public $listId;
}
