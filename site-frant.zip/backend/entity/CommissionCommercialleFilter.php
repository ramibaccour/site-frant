<?php
class CommissionCommercialleFilter
{
public $id;
public $dateDocument;
public $dateCommission;
public $typeDocument;
public $pourcent;
public $totalHt;
public $totalTva;
public $totalTtc;
public $totalCommission;
public $idUserCommerciale;
public $idDocument;
public $idUser;
public $document;
public $user;
}
