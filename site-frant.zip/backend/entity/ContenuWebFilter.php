<?php
class ContenuWebFilter
{
public $id;
public $nomLng1;
public $nom2Lng1;
public $textLng1;
public $text2Lng1;
public $image;
public $number1;
public $ordre;
public $isDeleted;
public $idContenuWebType;
public $idArticle;
public $idCategorie;
public $idParametre;
}
