<?php
define('DB_HOST', 'localhost:3306');
define('DB_USER', 'root');
define('DB_PASS', 'root');
define('DB_NAME', 'big_open');

// define('DB_HOST', 'localhost:3306');
// define('DB_USER', 'qjufmdrw_rami');
// define('DB_PASS', '8zz*x[H7iP?a');
// define('DB_NAME', 'qjufmdrw_big_open');

 $baseHose = "https://mirna.bio";
 $myHoste = $baseHose;
// $baseHose = "https://localhost";
// $myHoste = $baseHose. "/site-frant";

$loginBestDrlivery = "Mirnabyghada";
$passwordBestDrlivery = "Ghadamirnabio1";
